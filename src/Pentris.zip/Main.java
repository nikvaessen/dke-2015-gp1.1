import javax.swing.JFrame;

public class Main{
	public static void main(String[] argv){
		Board board = new Board(15,10);
		BoardHandler bh = new BoardHandler(board);
		InputController in = new InputController(bh);
		JFrame gui = new GUI(in);
		
	}
}