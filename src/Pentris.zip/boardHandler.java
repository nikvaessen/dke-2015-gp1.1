  public class boardHandler
    {
    	private Board board;
    	char[][] board = new char[15][10];


    public boardHandler(Board board)
    {
    	this.board = board;

    }


     public void moveRight()
     {
     	if(isCellEmpty( x , y + 1 ) == true)
     	{
     		board[x][y + 1] = board[x][y] ;
     	}
     	board.printBoard();
     
     }

     public void moveLeft()
     {
     	if(isCellEmpty( x , y - 1 ) == true)
     	{
     		board[x][y - 1] = board[x][y] ;
     	}
     	board.printBoard();
     
     }  


     public void moveDown()
     {
     	if(isCellEmpty( x + 1 , y ) == true)
     	{
     		board[x + 1][y] = board[x][y] ;
     	}
     	board.printBoard();
     }

     
    }