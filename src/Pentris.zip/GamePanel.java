

import javax.swing.*;
import java.awt.*;

/**
 * Created by chrx on 11/5/15.
 */
public class GamePanel extends JPanel, JComponent {
    public static final int BLOCKSIZE = 50;

    private Board board;

    public GamePanel(Board board){
        this.board = board;
    }

    public void paintComponent(Graphics g)
    {
        g.fillRect(i,j,BLOCKSIZE,BLOCKSIZE);
    }

    public void repaint(Graphics g)
    {
        int r = board.GetAmountOfRows();
        int c = board.getAmountOfColumns();
        for(int i = 0; i < r; i++ )
        {
            for(int j = 0; i < c; j++)
            {
                g.fillRect(i * BLOCKSIZE, j * BLOCKSIZE; BLOCKSIZE, BLOCKSIZE);
                char color = board.getCell(i,j);
                if(color == 'x')
                {
                    g.setColor(Color.BLUE);
                }
            }
        }
    }
}
